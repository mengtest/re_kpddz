-- --------------------------------------------------


-- *
-- * Summary: 	脚本配置数据
-- * Version: 	1.0.0
-- * Author: 	WP.Chu
-- --------------------------------------------------


-- 游戏名字
g_strGameName = "wd_poker"
g_luaVersion = "10"
g_logState = sluaAux.luaSvrManager.getInstance():GetLogState()
