--表名: 下注倍率, 字段描述：_key:编号, _commision:下注倍率, 
local M = {}
M["1"] = {key = "1", commision = "5,10,15,20,25", }
M["2"] = {key = "2", commision = "5,10,15,20,25", }
M["3"] = {key = "3", commision = "5,10,15,20,25", }
M["4"] = {key = "4", commision = "5,10,15,20,25", }
M["5"] = {key = "5", commision = "5,10,15,20,25", }
M["6"] = {key = "6", commision = "5,10,15,20,25", }
LuaConfigMgr.BottomPowerConfigLen = 6
LuaConfigMgr.BottomPowerConfig = M