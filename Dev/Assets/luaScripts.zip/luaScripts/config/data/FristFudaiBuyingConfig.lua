--表名: 首次购福袋奖励, 字段描述：_key:ID, _reward:奖励, 
local M = {}
M["1"] = {key = "1", reward = {{"item", "101", "500", }, {"item", "102", "8", }, }, }
LuaConfigMgr.FristFudaiBuyingConfigLen = 1
LuaConfigMgr.FristFudaiBuyingConfig = M