--表名: 超级水果积分榜, 字段描述：_key:排名, _item_reward:奖励比例, 
local M = {}
M["1"] = {key = "1", item_reward = "22", }
M["2"] = {key = "2", item_reward = "13", }
M["3"] = {key = "3", item_reward = "10", }
M["4"] = {key = "4", item_reward = "8", }
M["5"] = {key = "5", item_reward = "7", }
M["6"] = {key = "6", item_reward = "6", }
M["7"] = {key = "7", item_reward = "5", }
M["8"] = {key = "8", item_reward = "4.5", }
M["9"] = {key = "9", item_reward = "4", }
M["10"] = {key = "10", item_reward = "3.5", }
M["11"] = {key = "11", item_reward = "3", }
M["12"] = {key = "12", item_reward = "2.5", }
M["13"] = {key = "13", item_reward = "2", }
M["14"] = {key = "14", item_reward = "1.7", }
M["15"] = {key = "15", item_reward = "1.4", }
M["16"] = {key = "16", item_reward = "1.2", }
M["17"] = {key = "17", item_reward = "1", }
M["18"] = {key = "18", item_reward = "0.9", }
M["19"] = {key = "19", item_reward = "0.8", }
M["20"] = {key = "20", item_reward = "0.5", }
M["21"] = {key = "21", item_reward = "0.2", }
M["22"] = {key = "22", item_reward = "0.2", }
M["23"] = {key = "23", item_reward = "0.2", }
M["24"] = {key = "24", item_reward = "0.2", }
M["25"] = {key = "25", item_reward = "0.2", }
M["26"] = {key = "26", item_reward = "0.2", }
M["27"] = {key = "27", item_reward = "0.2", }
M["28"] = {key = "28", item_reward = "0.2", }
M["29"] = {key = "29", item_reward = "0.2", }
M["30"] = {key = "30", item_reward = "0.2", }
LuaConfigMgr.FruitRankingConfigLen = 30
LuaConfigMgr.FruitRankingConfig = M