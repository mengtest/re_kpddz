--活动说明
--表名: 活动规则, 字段描述：_key:ID, 
local M = {}
M["1"] = {key = "1", }
LuaConfigMgr.ActivityRulesConfigLen = 1
LuaConfigMgr.ActivityRulesConfig = M