--表名: 抢庄倍率, 字段描述：_key:编号, _commision:抢庄倍率, 
local M = {}
M["1"] = {key = "1", commision = "0,1,2,3,4", }
LuaConfigMgr.GrapPowerConfigLen = 1
LuaConfigMgr.GrapPowerConfig = M