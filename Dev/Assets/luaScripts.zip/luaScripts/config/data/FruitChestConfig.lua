--宝箱3奖励金币
--表名: 拉霸宝箱, 字段描述：_key:ID, _reward_gold1:ID, _reward_gold2:宝箱1奖励金币, _reward_gold3:宝箱2奖励金币, 
local M = {}
M["0"] = {key = "0", reward_gold1 = "35000", reward_gold2 = "90000", reward_gold3 = "350000", }
M["1"] = {key = "1", reward_gold1 = "35000", reward_gold2 = "90000", reward_gold3 = "350000", }
M["2"] = {key = "2", reward_gold1 = "35000", reward_gold2 = "90000", reward_gold3 = "350000", }
M["3"] = {key = "3", reward_gold1 = "70000", reward_gold2 = "180000", reward_gold3 = "700000", }
M["4"] = {key = "4", reward_gold1 = "70000", reward_gold2 = "180000", reward_gold3 = "700000", }
M["5"] = {key = "5", reward_gold1 = "70000", reward_gold2 = "180000", reward_gold3 = "700000", }
M["6"] = {key = "6", reward_gold1 = "350000", reward_gold2 = "900000", reward_gold3 = "3500000", }
M["7"] = {key = "7", reward_gold1 = "350000", reward_gold2 = "900000", reward_gold3 = "3500000", }
M["8"] = {key = "8", reward_gold1 = "350000", reward_gold2 = "900000", reward_gold3 = "3500000", }
M["9"] = {key = "9", reward_gold1 = "700000", reward_gold2 = "1800000", reward_gold3 = "7000000", }
M["10"] = {key = "10", reward_gold1 = "700000", reward_gold2 = "1800000", reward_gold3 = "7000000", }
LuaConfigMgr.FruitChestConfigLen = 11
LuaConfigMgr.FruitChestConfig = M