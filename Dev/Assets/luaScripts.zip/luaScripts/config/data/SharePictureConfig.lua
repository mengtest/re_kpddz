--表名: 分享图片尺寸, 字段描述：_key:排名, _qrisize:大小, _pos_x:X轴, _pos_y:Y轴, 
local M = {}
M["0"] = {key = "0", qrisize = "250", pos_x = "473", pos_y = "139", }
M["1"] = {key = "1", qrisize = "250", pos_x = "143", pos_y = "139", }
M["2"] = {key = "2", qrisize = "180", pos_x = "317", pos_y = "279", }
M["3"] = {key = "3", qrisize = "300", pos_x = "327", pos_y = "622", }
M["4"] = {key = "4", qrisize = "300", pos_x = "470", pos_y = "174", }
LuaConfigMgr.SharePictureConfigLen = 5
LuaConfigMgr.SharePictureConfig = M